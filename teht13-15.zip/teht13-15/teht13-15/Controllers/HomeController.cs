﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using teht13_15.Models;

namespace teht13_15.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult City()
        {
            return View();
        }
        public IActionResult Save(string city, double temperature)
        {
            JArray array;

            if (new FileInfo(@"C:\temp\cities.json").Length == 0)
            {
                array = new JArray();
                // empty
            }
            else
            {
                string json = System.IO.File.ReadAllText(@"C:\temp\cities.json");
                array = JArray.Parse(json);
            }
           
            
            JObject o = new JObject
            {
                {"City", city },
                {"Temperature", temperature }
            };
            array.Add(o);

            //write string to file
            System.IO.File.WriteAllText(@"c:\temp\cities.json", JsonConvert.SerializeObject(array, Formatting.Indented));
            return View("City");
        }
        public IActionResult Show()
        {
            JArray array = JArray.Parse(System.IO.File.ReadAllText(@"C:\temp\cities.json"));
            var list = new Dictionary<string, double>();
            
            foreach(JObject obj in array)  
            {
                list.Add(obj.GetValue("City").ToString(), (double)obj.GetValue("Temperature"));
            }
            
            ViewData["cities"] = list;
            

            


            return View("City");

        }

        public IActionResult Delete(string toDelete)
        {
            JArray array = JArray.Parse(System.IO.File.ReadAllText(@"C:\temp\cities.json"));
            var list = new Dictionary<string, double>();

            foreach (JObject obj in array)
            {
                if(obj["City"].ToString().Equals(toDelete))
                {
                    obj.Remove();
                    System.IO.File.WriteAllText(@"c:\temp\cities.json", JsonConvert.SerializeObject(array, Formatting.Indented));
                    return View("City");
                }
            }

           

            //write string to file
           





            return View("City");

        }
    }
}
