package com.example.tr.teht37b;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class AnswerActivity extends AppCompatActivity {
    ArrayList<String> listItems=new ArrayList<String>();
    private ArrayAdapter<String> adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_answer);

        adapter = new ArrayAdapter<String>(this,
                R.layout.list, listItems);
        final ListView listView = (ListView) findViewById(R.id.listAnswer);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position,
                                    long id) {
                Intent intent = new Intent(AnswerActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });




        RequestQueue queue = MySingleton.getInstance(this.getApplicationContext()).
                getRequestQueue();
        String url ="http://codez.savonia.fi/jussi/j2me/test_json.php?query=A";

// Request a string response from the provided URL.


        JsonArrayRequest stringRequest = new JsonArrayRequest
                (url,
                        new Response.Listener<JSONArray>()
                        {
                            @Override
                            public void onResponse(JSONArray response)
                            {

                                // Display the first 500 characters of the response string.
                                try {
                                    Funktio(response);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        }, new Response.ErrorListener()
                {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        //adapter.add("That didn't work!");
                        //adapter.notifyDataSetChanged();

                    }
                });
// Add the request to the RequestQueue.
        MySingleton.getInstance(this).addToRequestQueue(stringRequest);


    }
    public void Funktio(JSONArray response) throws JSONException
    {
        Intent intent = getIntent();
        String qst = intent.getStringExtra("question");

        SQLiteDatabase mydatabase = openOrCreateDatabase("db",MODE_PRIVATE,null);

        Cursor resultSet = mydatabase.rawQuery("Select * from Questions WHERE question = ? ",new String[] {qst});
        resultSet.moveToFirst();


        String id = resultSet.getString(0);
        String question = resultSet.getString(1);

        System.out.println("JWOIQEJQWOIEWJQOIE:             "+id + question);

        JSONObject json_data = null;

        for(int i=0; i < response.length() ; i++)
        {
            json_data = response.getJSONObject(i);

            String ida = json_data.getString("q_id");
            String txt = json_data.getString("txt");


            Log.d(txt, "Output");

            if(ida.equals(id))
            {
                adapter.add(txt);
                adapter.notifyDataSetChanged();
            }

        }

    }
}
